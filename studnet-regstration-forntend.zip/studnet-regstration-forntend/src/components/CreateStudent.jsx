import React, { useState } from 'react'
import { HttpProxy } from 'vite';

export default function CreateStudent() {
    const [name, setName] = useState('');
    const [NRC, setNRC] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [gender, setGender] = useState('');
    const [hobby, setHobby] = useState('');
    const [DateOfBirth, setDateOfBirth] = useState('');
    const [password, setPassword] = useState('');
    const [address, setAddress] = useState('');
    const [region, setRegion] = useState('');
    const [capital, setCapital] = useState('');
    const [township, setTownship] = useState('');
    const [street, setStreet] = useState('');
    const [year, setYear] = useState('');
    const [bachelor, setBachelor] = useState('');

    const NameHandler = (e) => setName(e.target.value);
    const NRCHandler = (e) => setNRC(e.target.value);
    const EmailHandler = (e) => setEmail(e.target.value);
    const PhoneHandler = (e) => setPhone(e.target.value);
    const GenderHandler = (e) => setGender(e.target.value);
    const HobbyHandler = (e) => setHobby(e.target.value);
    const DateOfBirthHandler = (e) => setDateOfBirth(e.target.value);
    const AddressHandler = (e) => setAddress(e.target.value);
    const RegionHandler = (e) => setRegion(e.target.value);
    const CapitalHandler = (e) => setCapital(e.target.value);
    const TownshipHandler = (e) => setTownship(e.target.value);
    const StreetHandler = (e) => setStreet(e.target.value);
    const YearHandler = (e) => setYear(e.target.value);
    const BachelorHandler = (e) => setBachelor(e.target.value);


    const SubmitHandler = e => {
        e.preventDefault();
        const students = {}
    }

  return (
   <>
        <div className="row">
            <div className="col">
                <div className="card">
                    <div className="card-header">
                        <h3>Create Student Form</h3>
                    </div>
                    <div className="card-body">
                        <form>
                            <div className='mb-3'>
                                <label className='form-label'>Name</label>
                                <input type="text" className='form-control' name='name' value={name} onChange={NameHandler} />
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Email</label>
                                <input type="text" name='email' className='form-control'   value={email} onChange={EmailHandler} />
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>NRC</label>
                                <input type="text" name='nrc'  className='form-control'  value={NRC} onChange={NRCHandler} />
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Phone</label>
                                <input type="text" name='phone' className='form-control'  value={phone} onChange={PhoneHandler} />
                            </div>
                            <div className='mb-3'>
                               <div className="container">
                                        <div className="row">
                                            <div className="col-md-6">
                                            <label className='form-check-label'>Male</label>
                                            <input type="radio" name='gender'  value={gender} onChange={GenderHandler} /> <br/>

                                            <label className='form-check-label'>Female</label>
                                            <input type="radio" name='gender'  value={gender} onChange={GenderHandler} />
                                            </div>
                                            <div className="col-md-6">
                                            
                                            <input type="checkbox" name='hobby'  value={hobby} onChange={HobbyHandler} />
                                            <label className='form-check-label'>SWIMMING</label><br />

                                            
                                            <input type="checkbox" name='hobby'  value={hobby} onChange={HobbyHandler} />
                                            <label className='form-check-label'>READING</label><br />

                                           
                                            <input type="checkbox" name='hobby'  value={hobby} onChange={HobbyHandler} />
                                            <label className='form-check-label'>CODING</label><br />

                                            
                                             <input type="checkbox" name='hobby'  value={hobby} onChange={HobbyHandler} />
                                             <label className='form-check-label'>SLEEPING</label> <br />

                                            <input type="checkbox" name='hobby'  value={hobby} onChange={HobbyHandler} />
                                            <label className='form-check-label'>GYM</label> <br />

                                           
                                            <input type="checkbox" name='hobby'  value={hobby} onChange={HobbyHandler} />
                                            <label className='form-check-label'>FOOTBALL</label>
                                            </div>
                                        </div>
                               </div>
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>DOB</label><br></br>
                                <input type="date" name='dob' value={DateOfBirth} onChange={DateOfBirthHandler} />
                            </div>
                            <div className='mb-3'>
                                <div className="row"> 
                                    <div className="col-md-2">
                                    <label className='form-label'>Address</label>
                                    <input type="text" name='address' className='form-control'  value={address} onChange={AddressHandler} />  
                                    </div>
                                    <div className="col-md-2">
                                    <label className='form-label'>Region</label>
                                    <input type="text" name='region' className='form-control'  value={region} onChange={RegionHandler} />
                                    </div>
                                    <div className="col-md-2">
                                    <label className='form-label'>Capital</label>
                                    <input type="text" name='capital' className='form-control'  value={capital} onChange={CapitalHandler} />
                                    </div>
                                    <div className="col-md-2">
                                    <label className='form-label'>Township</label>
                                    <input type="text" name='township' className='form-control'  value={township} onChange={TownshipHandler} />
                                    </div>
                                    <div className="col-md-2">
                                    <label className='form-label'>Street</label>
                                    <input type="text" name='street' className='form-control'  value={street} onChange={StreetHandler} />
                                    </div>
                                </div>
                            </div>
                            <div className="mb-3">
                                    <label className='form-label'>Year</label>
                                    <input type="date" name='year' value={year} onChange={YearHandler}/>
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Bachelor</label>
                                <input type="text" name='bachelor' value={bachelor} onChange={BachelorHandler} />
                            </div>

                            <button type='submit' className='btn btn-primary rounded' onClick={SubmitHandler}>Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
   </>
  )
}
