import axios from "axios";

const student=[]

const   STUDENT_API_BACKEND_UR = 'http://localhost:8080/api/students';


export const getAllStudents = () =>  axios.get(STUDENT_API_BACKEND_UR);



